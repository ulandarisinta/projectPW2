<?php

include "Controller/BukuController.php";

$aplikasi =  new BukuController();
$aplikasi->jalankan();