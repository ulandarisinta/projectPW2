<?php

require_once "orang.php";

class orangBiasa extends orang {

}