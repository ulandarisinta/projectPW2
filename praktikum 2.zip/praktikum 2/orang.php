<?php

class Orang{
    public $nama;

    public function ucapkanSalam(){
        echo "Assalamualaikum Perkenalkan Nama Saya".$this->nama;
    }
}